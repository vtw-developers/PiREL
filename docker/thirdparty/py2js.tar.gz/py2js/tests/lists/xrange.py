
xr = xrange(20,40)

for x in xr:
    print x
