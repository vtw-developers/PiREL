
l = [1,2,3,4,5,6,7,8,8]

l2 = filter(lambda x:x>4,l)

for v in l2:
    print v


