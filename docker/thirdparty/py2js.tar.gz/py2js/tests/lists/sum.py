
s = [1,2,3,4,5]
t = sum(s)
u = sum([x*x for x in s])
print t,u
