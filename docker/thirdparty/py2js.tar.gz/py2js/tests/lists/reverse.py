a = [1, 2, 3, 4]
a.reverse()
print a
