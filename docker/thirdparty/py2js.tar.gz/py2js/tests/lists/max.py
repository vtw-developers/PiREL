
l = [4,7,3,4,2,1]

v = max(l)

print v
