s = [1,2,3,4,5]
print sum(s)

print sum([1, 8, 11])

print sum((1, 8, 11))
