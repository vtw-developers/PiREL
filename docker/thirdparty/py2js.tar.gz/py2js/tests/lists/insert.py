a = []
a.insert(0, 1)
print a
a.insert(0, 2)
print a
a.insert(0, 3)
print a
a.insert(1, 4)
print a
a.insert(2, 5)
print a
a.insert(5, 6)
print a
