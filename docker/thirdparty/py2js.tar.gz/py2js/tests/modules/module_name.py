
import modules.module_name

print "1st level module __name__:"+__name__
