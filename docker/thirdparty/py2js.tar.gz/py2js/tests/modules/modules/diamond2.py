
import submodules.diamondbase

def run():
    print "Calling diamond2.run()"
    submodules.diamondbase.run()
