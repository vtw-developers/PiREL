
import submodules.diamondbase

def run():
    print "calling diamond1.run()"
    submodules.diamondbase.run()
