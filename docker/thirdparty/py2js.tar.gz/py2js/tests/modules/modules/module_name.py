
import submodules.module_name

print "2nd level module __name__:"+__name__
