
counter = 0

def run():
    global counter
    counter += 1
    print "diamondbase called " + str(counter) + " time(s)"
