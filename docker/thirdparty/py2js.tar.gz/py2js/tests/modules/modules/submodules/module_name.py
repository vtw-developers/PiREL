
print "3rd level module __name__:"+__name__
