
import imported.moduleb
import imported.moduled

imported.moduleb.moduleb_fn()
imported.moduled.moduled_fn()
