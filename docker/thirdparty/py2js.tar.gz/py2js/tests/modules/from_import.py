
from imported.modulea import modulea_fn
from imported.moduleb import moduleb_fn as modb_fn
from imported.modulec import *

modulea_fn()
modb_fn()
foo()
