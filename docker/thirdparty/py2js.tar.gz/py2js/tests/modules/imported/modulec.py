
import submodules.submodulea

def foo():
    print "imported.modulec.foo()"
    submodules.submodulea.foo()
