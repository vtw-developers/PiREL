
import imported.modulea

def moduled_fn():
    print "import_moduled.moduled_fn()"
    print "calling module a now..."
    imported.modulea.modulea_fn()
