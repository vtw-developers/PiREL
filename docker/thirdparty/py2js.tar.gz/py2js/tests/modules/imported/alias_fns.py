
def foo():
    print "this is foo"


