
def modulea_fn():

    print "import_modulea.modulea_fn()"

class modulea_class(object):

    def __init__(self):
        pass

    def msg(self,val):
        return "modulea_class:"+str(val)
