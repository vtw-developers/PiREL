
def foo():
    print "imported.modules.submodules.modulea.foo()"
