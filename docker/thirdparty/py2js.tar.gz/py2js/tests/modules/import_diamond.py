
import modules.diamond1
import modules.diamond2

modules.diamond1.run()
modules.diamond2.run()

