
import imported.modulec

def foo():
    print "foo"
    imported.modulec.foo()

foo()
