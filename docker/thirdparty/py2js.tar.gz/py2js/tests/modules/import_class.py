

import modules.klasses

k = modules.klasses.klass()

k.sayhello()
modules.klasses.klass.sayhello()

