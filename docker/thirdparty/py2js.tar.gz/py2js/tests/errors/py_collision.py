a = 1
if a == 1:
    print "ok"
else:
    print "no"

py_builtins = 1
if py_builtins == 1:
    print "ok"
else:
    print "no"

for py_builtins in range(5):
    a += py_builtins

print a
