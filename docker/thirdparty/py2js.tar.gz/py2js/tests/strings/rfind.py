
s = "the quick brown quick the fox"
i = s.rfind("quick")
print str(i)
i = s.rfind("dog")
print str(i)
i = s.rfind("the")
print str(i)
