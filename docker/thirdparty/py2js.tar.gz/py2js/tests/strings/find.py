
s = "the quick brown fox"
i = s.find("quick")
print str(i)
i = s.find("dog")
print str(i)
i = s.find("the")
print str(i)
