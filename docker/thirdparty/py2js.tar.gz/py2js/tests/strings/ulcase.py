

str = "aBcddEzUh"

print str
str = str.upper()
print str
str = str.lower()
print str
