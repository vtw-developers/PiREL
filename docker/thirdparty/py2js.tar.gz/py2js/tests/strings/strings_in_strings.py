print """"Hello World!" <- should 'mess' up '''thing'''?"""

# Test other strings:
print b"\\x00"
print u"\\u0000"
