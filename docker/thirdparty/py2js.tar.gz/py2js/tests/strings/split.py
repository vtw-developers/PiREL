
s="the     quick brown fox jumped over the lazy dog"
t = s.split(" ")
for v in t:
    print v
r = s.split("e")
for v in r:
    print v
x = s.split()
for v in x:
    print v

# 2-arg version of split not supported
# y = s.split(" ",7)
# for v in y:
#     print v
