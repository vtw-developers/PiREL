
txt = """
aaa

bcfdss

sdsd
wqarwqr


werewr"""

lines = txt.splitlines()

for line in lines:
    print line
