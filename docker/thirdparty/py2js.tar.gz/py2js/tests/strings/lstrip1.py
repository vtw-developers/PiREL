

s = "abcxyz"

print "original("+s+")"
print "strip("+s.lstrip("cba")+")"
