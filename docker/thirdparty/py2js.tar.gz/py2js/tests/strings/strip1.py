

s = "yxabcxyz"

print "original("+s+")"
print "strip("+s.strip("yzx")+")"
