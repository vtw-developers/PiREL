a = "well"
b = "seems to work"
c = "something else"
d = 10
f = 15

s = "%s: %d, %s: %d, %s: %d" % (a, d, b, f, c, d)
print s
