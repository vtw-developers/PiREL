
txt = "the quick brown fox jumped over thethe lazy dog"

txt2 = txt.replace("the","a")

print txt
print txt2

print txt.replace("the", "a", 0)
print txt.replace("the", "a", 1)
print txt.replace("the", "a", 2)
print txt.replace("the", "a", 3)
print txt.replace("the", "a", 4)
print txt.replace("the", "a", 50)
