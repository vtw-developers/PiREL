

s = "abcxyz"

print "original("+s+")"
print "strip("+s.rstrip("yzx")+")"
