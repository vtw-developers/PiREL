a = ["a", "b", "c"]
print "".join(a)
print " ".join(a)
print "x".join(a)
print "x ".join(a)
