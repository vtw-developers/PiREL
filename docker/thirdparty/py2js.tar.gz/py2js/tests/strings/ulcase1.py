

a = "aBcddEzUh"

print a
a = a.upper()
print a
a = a.lower()
print a
