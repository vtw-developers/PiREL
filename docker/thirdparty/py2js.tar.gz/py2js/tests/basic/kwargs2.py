def myfunc(a, b=3, c=4):
    print a
    print b
    print c
    print

myfunc(1)
myfunc(1, 2)
myfunc(1, 2, 3)
myfunc(1, c=3, b=4)
myfunc(1, b=4)
