
literals = ['a','',0,None,1,0.0,1.0,-1,-1.0,-0]

for l in literals:
    if l:
        print "True"
    else:
        print "False"
