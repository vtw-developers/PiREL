
x = 1
y = 2
z = 3

print 10 % z
print y*x
print y-z
print y+x+z
print 10 / 2
print 10 ** 2
