
x = 0

while True:
    x = x + 1
    print x
    if x > 10:
        break
