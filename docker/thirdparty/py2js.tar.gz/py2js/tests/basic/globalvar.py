

a = "spam"
b = "eggs"

print a
print b
