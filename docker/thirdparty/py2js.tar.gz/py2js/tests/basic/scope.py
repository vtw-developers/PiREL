
x = 12

def loopy():
    for x in xrange(0,8):
        print x

loopy()
print x
