
y = lambda x:x*x

print y(4)

