
x = 'hello'

if x != 'hello':
    print "1"
    pass
    print "2"
else:
    print "3"
    pass
    print "4"


