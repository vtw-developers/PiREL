
a = 1
a += 1
print a
a += 3
print a
a -= 2
print a
