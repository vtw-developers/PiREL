
mylist = [1,2,3,4,5]

del mylist[3]

for x in xrange(0,len(mylist)):
    print mylist[x]
