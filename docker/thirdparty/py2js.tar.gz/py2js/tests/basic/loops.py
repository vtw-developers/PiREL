def loop1(x):
    a = 0
    for i in range(x):
        x
        a += i
    return a

print loop1(1)
print loop1(2)
print loop1(3)
print loop1(4)
print loop1(5)
print loop1(6)
print loop1(7)
