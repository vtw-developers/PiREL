
for x in xrange(1,10):
    print x
