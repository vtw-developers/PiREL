
x = True
y = False
z = not y

if x:
    print 'x'
if y:
    print 'y'
if z:
    print 'z'
