
for x in xrange(19,342,13):
    print x
