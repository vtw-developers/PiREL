
x = None

if x == None:
    print "x is None/null"
else:
    print "x is not None/null"
