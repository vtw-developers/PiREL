
for x in xrange(0,20):
    if x > 10 and x < 17:
        continue
    print x
