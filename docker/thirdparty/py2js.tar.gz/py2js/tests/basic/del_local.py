
x = "ABC"

print x

del x

try:
    print x
except:
    print "x is gone"
