
x = [1,2,3,'a','b','c']
y = x[2:4]
print x[0]
print x[3]
print y[0]
print y[1]
