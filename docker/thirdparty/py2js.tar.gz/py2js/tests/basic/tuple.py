
tup = ('a','b',1,2,3)

print tup[0]
print tup[1]
print tup[2]
print tup[3]
print tup[4]
