
print 1.23, "foobar", -1, 'x'
