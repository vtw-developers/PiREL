
print('hello')
print('hello world')
