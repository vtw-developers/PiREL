class A(object):
    v = 1

a = A()
XX = A
x = XX()
print x.v
