
a = 1.234
b = 3
c = 3.45
d = 'cats'

print a
print b
print c
print d
