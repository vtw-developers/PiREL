
foo = { 'a':'b', 'c':'d' }

print foo['a']
print foo['c']

if 'a' in foo:
    print "a in foo"
