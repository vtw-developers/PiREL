
a = '123.456'
b = float(a)
print b
