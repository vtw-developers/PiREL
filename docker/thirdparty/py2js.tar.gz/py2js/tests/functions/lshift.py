
x = 10
y = x << 3
x <<= 3
print x,y
