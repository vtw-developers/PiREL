x = 32213
y = 98743
z = x ^ y
print z
