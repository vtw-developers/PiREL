
x = 123
y = 233
y2 = 233
z = 892

if x < y:
    print "x < y - correct"
else:
    print "not x < y - incorrect"

if y <= y2:
    print "y <= y2 - correct"
else:
    print "not y <= y2 - incorrect"

if z < x:
    print "z < x - incorrect"
else:
    print "not z < x - correct"

if y <= z:
    print "y <= z - correct"
else:
    print "not y <= x - incorrect"

