
l = [3,2,1]

l.sort()

print l[0]
print l[1]
print l[2]
