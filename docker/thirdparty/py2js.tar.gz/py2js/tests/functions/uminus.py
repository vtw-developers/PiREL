
x = -7623
print x
