
x = 23423
y = 213
z = x // y

print z
