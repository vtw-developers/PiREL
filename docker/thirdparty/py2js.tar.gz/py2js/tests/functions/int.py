
x = '123'
y = int(x)
print y
