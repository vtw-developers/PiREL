
x = 32424
y = 1437
z = x & y
print z
