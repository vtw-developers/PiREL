
b = (~1 & 0xFFFF)
print b
