from __future__ import division

a = 244
b = 23

print a
a += 4
print a
a -= 2
print a
a <<= 4
print a
a >>= 2
print a
a |= 234324
print a
a &= 213213
print a
a ^= 2312
print a
a //= 324
print a
a += 1
print a
a /= 2
print a

print b
b **= 3
print b
