
x = 345
y = x >> 7
x >>= 7
print x,y
