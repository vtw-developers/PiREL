

for (x,y) in [(1,2),('aaa','bbb'),(4,4),('a','a')]:
    if x <> y:
        print str(x)+" <> "+str(y)
    else:
        print "not: " + str(x)+" <> "+str(y)


