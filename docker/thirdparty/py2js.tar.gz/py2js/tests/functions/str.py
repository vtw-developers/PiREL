
a = 1
b = str(a)
c = 'x: ' + b
print a
print b
print c
