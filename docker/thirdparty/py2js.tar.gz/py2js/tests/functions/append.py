
mylist = []
mylist.append('a')
mylist.append('b')
mylist.append('c')

print mylist[0]
print mylist[1]
print mylist[2]
