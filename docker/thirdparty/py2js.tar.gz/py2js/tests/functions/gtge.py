
x = 123
y = 233
y2 = 233
z = 892

if x > y:
    print "x > y - incorrect"
else:
    print "not x > y - correct"

if y >= y2:
    print "y >= y2 - correct"
else:
    print "not y >= y2 - incorrect"

if z > x:
    print "z > x - correct"
else:
    print "not z > x - incorrect"

if y >= z:
    print "y >= z - incorrect"
else:
    print "not y >= x - correct"

