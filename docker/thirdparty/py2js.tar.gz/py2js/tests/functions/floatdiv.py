
from __future__ import division

a = 3
b = 2
c = a / b
print c
