
x = 123215
y = 3423
z = x | y
print z
